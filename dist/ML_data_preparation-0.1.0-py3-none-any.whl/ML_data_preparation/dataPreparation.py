from encoding import encode_categorical
from missingValue import handle_missing_values
from scale import scale_data
from split import split_dataset